%% Problem set 2, question 6, 205C, Spring 2016
%  fg_ps2_q6.m
% Matlab code for question 6 of problem set 2.
clear all
close all
clc

%% parameters
p.sigma     = 1;
p.beta      = 0.99;
p.kappa     = 0.08;
p.N         = 3;    % t+N is last period nominal rate is constrained at zero

T           = 15;
periods     = 1:T;
% display all parameters
p  % this illustrates a simple structure in matlab

disp('Hit any key to continue')
pause
 %% equilibrium equations
%  equilibrium is solved backward from t+N+M since for all t => t+N+M, the
% nominal rate follows the rule pi(t) + psi*x(t) which implies x(t) = pi(t) = 0;

% The real rate process is
rn  = zeros(T,1);
rn(1:1+p.N)   = -0.02;
rn(1+p.N+1:T) = 0.03;

ni = rn;

%%
% The system is A*[x(t+1) pi(t+1)]' = B*[x(t) pi(t)]' + C*(ni(t) - rn(t)) where
A   = [1 1/p.sigma; 0 p.beta];
B   = [1 0; -p.kappa 1];
C   = [1/p.sigma; 0];
Q   = B\A;
P   = B\C;

%% System is now [x(t) pi(t)]' = Q*[x(t+1) pi(t+1)]' - P*(ni(t) - rn(t)) 
%  loop over values of M
M  = [0 3 4 5 6];
MN = size(M,2);
%  results will be stored in x and pi
x   = zeros(T,MN);
pi  = zeros(T,MN);
ni  = zeros(T,MN);
for j = 1:MN;
    ni(1:1+p.N+M(j),j) = 0;
    ni(1+p.N+M(j)+1:T,j) = rn(1+p.N+M(j)+1);
    Z   = zeros(2,T);
    for i = 1:T-1
        Z(:,T-i) = Q*Z(:,T+1-i) - P*(ni(T-i,j) - rn(T-i));
    end
    x(:,j)  = Z(1,:)';
    pi(:,j) = Z(2,:)';
end
    
%% plotting the results
subplot(2,1,1)
plot(periods,x(:,1),'b-',periods,x(:,2),'b--',periods,x(:,3),'b:',periods,x(:,4),'b:o',periods,x(:,5),'b--d')
hold on
plot(periods,zeros(T,1),'k','LineWidth',1.2)
title('Output gap')
legend('M = 0','M = 2','M = 4','M = 5','M = 6')

axis([1 T -Inf Inf])
subplot(2,1,2)
plot(periods,pi(:,1),'r-',periods,pi(:,2),'r--',periods,pi(:,3),'r:',periods,pi(:,4),'r:o',periods,pi(:,5),'r--d');
legend('M = 0','M = 2','M = 4','M = 5','M = 6')
hold on
plot(periods,zeros(T,1),'k','LineWidth',1.2)
title('Inflation rate')
axis([1 T -Inf Inf])







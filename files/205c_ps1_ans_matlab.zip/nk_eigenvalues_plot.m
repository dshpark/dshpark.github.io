%% Problem set 1, 205C, Sp 2017, Q2.b
%  nk_eigenvalue_plot.m
clear all
close all
clc

%% Parameters
sigma   = 1;
eta     = 1;
beta    = 0.99;
rho     = 0.9;
omega   = 0.75;
kappa   = (1-omega)*(1-beta*omega)*(sigma+eta)/omega;

MM      = [(kappa+sigma*beta)/(sigma*beta) -1/sigma*beta; -kappa/beta  1/beta];
%% Range of parameter phi
phi = 0:0.005:2;
phi = phi';     % coverts phi to a column vector with I find mroe convenient.

% A made up matrix. 
% Note that for each value of phi, M is 2 x 2. So I define M as a 2 x 2 x N
% matrix where N is the number of values of phi I am evaluating.
for i = 1:size(phi,1);
    M(:,:,i) = [MM(1,1) (beta*phi(i) - 1)/(sigma*beta); MM(2,1) MM(2,2)]; %M is a 2x2xN matrix when N is size of phi
end
%% Find the absolute value of the eigenvalues
for i = 1:size(phi,1)
    EIGM(i,:) = sort(abs(eig(M(:,:,i))));
end
%%
oo = ones(size(phi,1),1);
plot(phi,EIGM(:,1),phi,EIGM(:,2),'b--','LineWidth',1.2)
hold on
plot(phi,oo,'k','LineWidth',1)
annotation('line',[0.5188 0.5188],...
    [0.113285714285714 0.917857142857143],'LineWidth',1);
text(0.34,0.7,'Smallest eigenvalue')
text(0.4,1.475,'Largest eigenvalue')
xlabel('\phi','FontSize',14)
hold off

%% This plots only the smaller of the two eigenvalues
oo = ones(size(phi,1),1);
plot(phi,EIGM(:,1),'LineWidth',1.2)
hold on
plot(phi,oo,'k','LineWidth',1)
hold off
